package com.utn.utnApiRest.services;

import com.utn.utnApiRest.entities.Autor;

public interface AutorService extends BaseService<Autor, Long>{
}
